﻿
using System;
using System.IO;
using System.Net;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;
using System.Xml.Linq;

class JsonFormatter
{
    static void Main()
    {
        try
        {
            WebClient client = new WebClient();
            string s = client.DownloadString("https://coderbyte.com/api/challenges/json/json-cleaning");
            Console.WriteLine(s);

            if (!String.IsNullOrEmpty(s))
            {
                JObject jObject = JObject.Parse(s);

                JsonCleaner(jObject);
                Console.WriteLine(jObject.ToString());
                Console.ReadLine();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }

    private static void JsonCleaner(JToken token)
    {
        if (token.Type == JTokenType.Object)
        {
            var obj = (JObject)token;
            foreach (var prop in obj.Properties().ToList())
            {

                if (prop.Value.Type == JTokenType.String && ((string)prop.Value == "N/A" || (string)prop.Value == ""))
                {
                    prop.Remove();
                }
                else
                {
                    JsonCleaner(prop.Value);
                }
            }
        }
    }
}