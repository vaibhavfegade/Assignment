﻿using System;
using System.Net;
using Newtonsoft.Json.Linq;
using System.Linq;

class AgeCounter
{
    static void Main1()
    {
        try
        {
            WebClient client = new WebClient();
            string s = client.DownloadString("https://coderbyte.com/api/challenges/json/age-counting");

            if (!String.IsNullOrEmpty(s))
            {
                JObject jObject = JObject.Parse(s);

                string data = (String)jObject["data"];

                string[] kvPairs = data.Split(',');

                var count = kvPairs.Select(p => p.Trim().Split('='))
                    .Count(p => p[0].ToLower() == "age" && int.TryParse(p[1], out int age) && age >= 50);

                Console.WriteLine($"Total items with age greater or equal to 50 is {count}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }

}